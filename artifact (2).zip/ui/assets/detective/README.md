# Detective Mystery sounds

Stage completion effects sourced from Mixkit:

- `clue.mp3`: Camera shutter click
- `evidence.mp3`: Camera shutter hard click
- `solved.mp3`: Vintage camera shutter

Source: https://mixkit.co/free-sound-effects/camera/
License: https://mixkit.co/license/

`card-1.jpg` through `card-4.jpg` are generated built-in card backgrounds for
the Detective Mystery progression.
