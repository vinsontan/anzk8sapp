# Space Theme — Completion Sounds

Drop the following MP3 files into this folder and redeploy:

| File | Plays when… |
|---|---|
| `launch.mp3` | Mission 1 complete (beginner) |
| `orbit.mp3` | Mission 2 complete (intermediate) |
| `warp.mp3` | Mission 3 complete (advanced) |

Suggested sounds: rocket launch blast, orbital thruster burn, warp-speed whoosh.
