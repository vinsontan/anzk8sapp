# Superhero Theme — Completion Sounds

Drop the following MP3 files into this folder and redeploy:

| File | Plays when… |
|---|---|
| `sidekick.mp3` | Mission 1 complete (beginner) |
| `hero.mp3` | Mission 2 complete (intermediate) |
| `legend.mp3` | Mission 3 complete (advanced) |

Suggested sounds: whoosh/power-up, triumphant fanfare, epic orchestral swell.
