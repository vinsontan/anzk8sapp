# Wizard Academy sounds

Stage completion effects sourced from Mixkit:

- `initiate.mp3`: Shot light energy flowing
- `spellcaster.mp3`: Magic sparkle whoosh
- `archmage.mp3`: Magic notification ring

Source: https://mixkit.co/free-sound-effects/magic/
License: https://mixkit.co/license/

`card-1.jpg` through `card-4.jpg` are generated built-in card backgrounds for
the Wizard Academy progression.
