# Football Theme — Completion Sounds

Drop the following MP3 files into this folder and redeploy:

| File | Plays when… |
|---|---|
| `whistle.mp3` | Round 1 complete (beginner) |
| `halftime.mp3` | Round 2 complete (intermediate) |
| `fulltime.mp3` | Round 3 complete (advanced) |

Suggested sounds: referee whistle, half-time buzzer, full-time crowd roar + whistle.
