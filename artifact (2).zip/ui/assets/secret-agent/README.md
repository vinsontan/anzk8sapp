# Secret Agent sounds

Stage completion effects sourced from Mixkit:

- `briefing.mp3`: Sci-fi click
- `infiltration.mp3`: Technological futuristic hum
- `extraction.mp3`: Interface hint notification

Source: https://mixkit.co/free-sound-effects/high-tech/
License: https://mixkit.co/license/

`card-1.jpg` through `card-4.jpg` are generated built-in card backgrounds for
the Secret Agent progression. Their spy-thriller scenes incorporate
Dynatrace-inspired service-flow topology, distributed traces, anomaly signals,
and the purple-blue-lime-green visual palette.
